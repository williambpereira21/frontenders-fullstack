const firebaseConfig = {
  apiKey: "AIzaSyBkw0oeHa7VTfvlQBEoF5oXA8BP0tiKTqg",
  authDomain: "frontenders1-208d5.firebaseapp.com",
  projectId: "frontenders1-208d5",
  storageBucket: "frontenders1-208d5.firebasestorage.app",
  messagingSenderId: "715966897596",
  appId: "1:715966897596:web:6ebef7980f7ee4f5115fb9"
};