const firebaseConfig = {
  apiKey: "AIzaSyBHC6fxBShUXjcdjBFjJ8k1bF34HKKVP3c",
  authDomain: "frontenders-1d1c1.firebaseapp.com",
  projectId: "frontenders-1d1c1",
  storageBucket: "frontenders-1d1c1.firebasestorage.app",
  messagingSenderId: "991944134559",
  appId: "1:991944134559:web:df606bb7575a07489e77aa"
};